/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this repplate file, choose Tools | Templates
 * and open the repplate in the editor.
 */
package cprogass06a_bizimanapj;
import javax.swing.JOptionPane;
/**
 *
 * @author Prince
 */

  public class SalesRepController {

    
    static SalesRep[] repList;
    static String InputString;
    final static String HEADING = "Sales Rep Listing";
    static int numOfReps;

    public static void main(String[] args) {
        
     
        final String PromptString =  "1. Unsorted List\n" 
                + "2. Sorted List\n" + 
                "3. Info\n" + "4. Find a rep\n" +
                "0. Exit\n";
        
        Boolean ExitTime = false;
        int Option;
        
        createRepList();
        
        
        while(!ExitTime)
        {
            
      
            InputString = JOptionPane.showInputDialog(null, PromptString, 
                    HEADING, JOptionPane.QUESTION_MESSAGE);
            Option = Integer.parseInt(InputString);
            
            
          
            switch (Option)
            {
            case 1: {printList(); break;}
            case 2: {printSortedList(); break;}
            case 3: {printListSummery(); break;}
            case 4: {querySalesRep(); break;}
            case 0: {ExitTime = true; break;}
            }
        }
    }
    

    public static void createRepList()
    {
        do{
            numOfReps = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of reps you want to add", 
                    HEADING, JOptionPane.QUESTION_MESSAGE));
        }while(numOfReps <= 0);
        
        
        repList = new SalesRep[numOfReps];
        
        
        for(int x = 0; x < numOfReps; x++)
        {
            SalesRep repp = new SalesRep();
            
            
            repp.name = JOptionPane.showInputDialog(null, "Enter the rep's name", 
                    "Sales Rep #" + (x + 1), JOptionPane.QUESTION_MESSAGE);
            
            
            repp.ID_Num = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the rep's ID number", 
                    "Sales Rep #" + (x + 1), JOptionPane.QUESTION_MESSAGE));
            
            repp.dept = JOptionPane.showInputDialog(null, "Enter the rep's department", 
                    "Sales Rep #" + (x + 1), JOptionPane.QUESTION_MESSAGE);
            
       
            repp.saleAmount = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the rep's sales amount", 
                    "Sales Rep #" + (x + 1), JOptionPane.QUESTION_MESSAGE));
            
            repList[x] = repp;
        }
    }
  
   
    public static void printListSummery()
    {
        int total = 0;
        double avg, stdDev, repp = 0;
    
        
        for(int x = 0; x < numOfReps; x++)
        {
            total = total + repList[x].saleAmount;
        }
    
       
        avg = (double)total/numOfReps;
    
       
        for(int x = 0; x < numOfReps; x++)
        {
            repp += (repList[x].saleAmount - avg) * (repList[x].saleAmount - avg);
        }
        repp = repp / (numOfReps - 1);
    
        stdDev = Math.sqrt(repp);
    
        
        int min = Integer.MIN_VALUE, highIndex = 0, max = Integer.MAX_VALUE, lowIndex = 0;
    
        for(int x = 0; x < numOfReps; x++)
        {
            if(repList[x].saleAmount > min)
            {
                min = repList[x].saleAmount;
                highIndex = x;
            }
        
            if(repList[x].saleAmount < max)
            {
                max = repList[x].saleAmount;
                lowIndex = x;
            }
        }
    
       
        String result = "List Summary:\n\nTotal Sales: " + total + "\nAverage Sales: " + avg
            + "\nStandard Deviation: " + stdDev + "\nHighest Selling Representative: " 
            + repList[highIndex].toString() + "Lowest Selling Representative: " 
            + repList[lowIndex].toString();
    
        JOptionPane.showInputDialog(null, result, HEADING, JOptionPane.QUESTION_MESSAGE);
}        
  
    public static void printList()
    {
        String result = "";
        
        for(int x = 0; x < numOfReps; x++)
        {
            result = result + repList[x].toString();
        }
        
        JOptionPane.showInputDialog(null, result, HEADING, JOptionPane.QUESTION_MESSAGE);
    }

    public static void printSortedList()
    {
        
        SalesRep[] reppList = repList; 
        
   
        boolean flag = true;  
        SalesRep repp = new SalesRep();  

        while(flag)
        {
            flag = false;
            for(int x = 0;  x < numOfReps - 1;  x++ )
            {
                if (reppList[x].saleAmount < reppList[x + 1].saleAmount )   
                {
                    repp.Modify(reppList[x]);  
                    reppList[x] = reppList[x + 1];
                    reppList[x + 1] = repp;
                    flag = true;                
                } 
            } 
        } 
        
        
        String result = "";
        
        for(int x = 0; x < numOfReps; x++)
        {
            result = result + reppList[x].toString();
        }
        
        JOptionPane.showInputDialog(null, result, HEADING, JOptionPane.QUESTION_MESSAGE);
    }
    
    public static void querySalesRep()
    {
        
        String numList = "ID Numbers:\n";
        int x;
        
        for(x = 0; x < numOfReps; x++)
        {
            numList = numList + Integer.toString(repList[x].ID_Num) + "\n";
        }
        
        
        numList = numList + "\n\n\nWhich employee would you like to display?";
        
        
        int ID_NumIn = Integer.parseInt(JOptionPane.showInputDialog(null, numList, 
                HEADING, JOptionPane.QUESTION_MESSAGE));
        
        
        for(x = 0; x < numOfReps; x++)
        {
            if(repList[x].ID_Num == ID_NumIn)
                break;
        }
        
        JOptionPane.showInputDialog(null, repList[x].toString(), HEADING, JOptionPane.QUESTION_MESSAGE);
    }

}
