/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cprogass06a_bizimanapj;

/**
 *
 * @author Prince
 */
public class SalesRep {
    
    
    String name, dept;
    int ID_Num, saleAmount;

    
    public SalesRep()
    {
                
    }
    
    public void InputData(String nameIn, int IDNumIn, String deptIn, int amountIn)
    {
        name = nameIn;
        ID_Num = IDNumIn;
        dept = deptIn;
        saleAmount = amountIn;
    }
    
    public void Modify(SalesRep repIn)
    {
        name = repIn.name;
        ID_Num = repIn.ID_Num;
        dept = repIn.dept;
        saleAmount = repIn.saleAmount;
    }
    
    public String toString()
    {
        String output;
        
        output = name + "\nID#: " + ID_Num + "\nDepartment: " + dept + "\nSales: " + saleAmount + "\n\n";
        
        return output;
    }
}
