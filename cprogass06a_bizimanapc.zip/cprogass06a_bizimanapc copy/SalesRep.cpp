/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SalesRep.cpp
 * Author: Prince
 * 
 * Created on April 1, 2017, 10:28 PM
 */

#include "SalesRep.h"
#include <string>


SalesRep::SalesRep() {
    
}

void SalesRep::Modify(SalesRep repIn)
{
    name = repIn.name;
    ID_Num = repIn.ID_Num;
    dept = repIn.dept;
    saleAmount = repIn.saleAmount;
}

void SalesRep::InputData(string nameIn, int IDNumIn, string deptIn, int amountIn)
{
    name = nameIn;
    ID_Num = IDNumIn;
    dept = deptIn;
    saleAmount = amountIn;
}

string SalesRep::toString()
{
    string output;
        
    output = name + "\nID#: " + to_string(ID_Num) + "\nDepartment: " + dept + "\nSales: " + to_string(saleAmount) + "\n\n";
        
    return output;
}
