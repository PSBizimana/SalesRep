/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Prince
 *
 * Created on April 1, 2017, 10:27 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <limits>
#include "SalesRep.h"
using namespace std;

static SalesRep* repList;
static string InputString;
const static string HEADING = "Sales Rep Listing";
static int numOfReps;

void createRepList();
void printListSummery();
void printList();
void printSortedList();
void querySalesRep();


int main(int argc, char** argv) {

    
    const string PromptString ="***MAIN MENU***\n1. Provide Unsorted List of Sales Reps\n2. Provide Sorted List of Sales Reps\n3. Provide Sales List Stats\n4. Query Sales Rep\n0. Exit\n";
        
        bool ExitTime = false;
        int Option;
        
        createRepList();
        while(!ExitTime)
        {
            
        
            cout << PromptString << endl;
            cin >> InputString;
            cout << endl << endl; 
             
            Option = stoi(InputString);
            
            
          
            switch (Option)
            {
            case 1: {printList(); break;}
            case 2: {printSortedList(); break;}
            case 3: {printListSummery(); break;}
            case 4: {querySalesRep(); break;}
            case 0: {ExitTime = true; break;}
            }
        }
    
    return 0;
}

void createRepList()
{
  
    do{
        cout << "How many sales reps do you want to enter?(enter an integer higher than 0)" << endl;
        cin >> numOfReps;
        cout << endl << endl;
    }while(numOfReps <= 0);
        
    repList = new SalesRep[numOfReps];
        
        
    for(int x = 0; x < numOfReps; x++)
    {
        SalesRep temp;
        cout << "Enter the rep #" + to_string(x + 1) + "'s name" << endl;
        cin >> temp.name;
        cout << endl;
        cout << "Enter the rep #" + to_string(x + 1) + "'s ID number" << endl;
        cin >> temp.ID_Num;
        cout << endl;
        cout << "Enter the rep #" + to_string(x + 1) + "'s department" << endl;
        cin >> temp.dept;
        cout << endl; 
        cout << "Enter the rep #" + to_string(x + 1) + "'s sales amount" << endl;
        cin >> temp.saleAmount;
        cout << endl;
        
        repList[x] = temp;
    }
}

void printListSummery()
{
    int total = 0;
    double avg, stdDev, temp = 0;
    
    for(int x = 0; x < numOfReps; x++)
    {
        total = total + repList[x].saleAmount;
    }
    
    avg = (double)total/numOfReps;
    
    for(int x = 0; x < numOfReps; x++)
    {
        temp += pow((repList[x].saleAmount - avg),2);
    }
    
    temp = temp / (numOfReps - 1);
    stdDev = sqrt(temp);
    
    
    int min = numeric_limits<int>::min(), highIndex = 0, max = numeric_limits<int>::max(), lowIndex = 0;
    
    for(int x = 0; x < numOfReps; x++)
    {
        if(repList[x].saleAmount > min)
        {
            min = repList[x].saleAmount;
            highIndex = x;
        }
        
        if(repList[x].saleAmount < max)
        {
            max = repList[x].saleAmount;
            lowIndex = x;
        }
    }
    

    string result = "List Summery:\n\nTotal Sales: " + to_string(total) + "\nAverage Sales: " + to_string(avg)
        + "\nStandard Deviation: " + to_string(stdDev) + "\nHighest Selling Representative: " 
        + repList[highIndex].toString() + "Lowest Selling Representative: " 
        + repList[lowIndex].toString();
    
    cout<< result << endl << endl;
}

void printList()
{
    cout << "Sales Rep List:\n" << endl;//prints header
            
    string result = "";
        
    for(int x = 0; x < numOfReps; x++)
    {
        result = result + repList[x].toString();
    }
        
    cout << result << endl << endl;
}

void printSortedList()
{

    SalesRep* tempList = repList; 
    bool flag = true;  
    SalesRep temp;  
    
    while(flag)
    {
        flag = false;
        for(int x = 0;  x < numOfReps - 1;  x++ )
        {
            if (tempList[x].saleAmount < tempList[x + 1].saleAmount )   
            {
                temp.Modify(tempList[x]);  
                tempList[x] = tempList[x + 1];
                tempList[x + 1] = temp;
                flag = true;              
            } 
        } 
    } 
       
    string result = "";
        
    for(int x = 0; x < numOfReps; x++)
    {
        result = result + tempList[x].toString();
    }
        
    cout << result << endl << endl;    
}   
    
    
void querySalesRep()
{   
        
    string numList = "ID Numbers:\n";
    int x, ID_NumIn;
        
    for(x = 0; x < numOfReps; x++)
    {
        numList = numList + to_string(repList[x].ID_Num) + "\n";
    }
        
    
    numList = numList + "\n\n\nDisplay the Employee you would like to see?";
    
    cout << numList << endl;
    cin >> ID_NumIn;
        
    for(x = 0; x < numOfReps; x++)
    {
        if(repList[x].ID_Num == ID_NumIn)
            break;
    }
        
    cout << endl; 
    cout << repList[x].toString() << endl;
}   